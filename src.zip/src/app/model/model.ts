
export type data = data2[]  

export class data2 {
    "Dedalus ID": string=""
    "Employee ID": string=""
    "Employee Name": string=""
    "Mail Id": string=""
    "Gender": string=""
    "Location": string=""
    "Product Group": string=""
    "Product": string=""
    "Unified Roles": string=""
    "Product Work Area": string=""
    "Work Group": string=""
    "HL Role": string;
    "HL Designation": string=""
    "HL Title": string=""
    "Reporting Manager": string=""
    "Manager Email": string=""
    "GET": string=""
    "CSC_DoJ": string=""
    "Date of Leaving": string=""
    "Unit": string=""
    "Owning": string=""
  }
  