import { TeamPipe } from './team.pipe';

describe('TeamPipe', () => {
  it('create an instance', () => {
    const pipe = new TeamPipe();
    expect(pipe).toBeTruthy();
  });
});
